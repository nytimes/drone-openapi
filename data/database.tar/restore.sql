--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test;
--
-- Name: test; Type: DATABASE; Schema: -; Owner: alexwilkerson
--

CREATE DATABASE test WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE test OWNER TO alexwilkerson;

\connect test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.category AS ENUM (
    'CANCEL_THE_CANCEL',
    'PRODUCT_CHANGE',
    'STS',
    'ACQUISITION'
);


ALTER TYPE public.category OWNER TO postgres;

--
-- Name: channel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.channel AS ENUM (
    'ACCOUNT',
    'CARE',
    'LANDING_PAGE',
    'ONLINE_CANCEL',
    'MARKETING_DRIVEN',
    'SUBSCRIBER_ADVOCACY'
);


ALTER TYPE public.channel OWNER TO postgres;

--
-- Name: hd_product_code; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.hd_product_code AS ENUM (
    'DS',
    'MF',
    'FS',
    'SS',
    'SO',
    'ST',
    'SW',
    'SR',
    '2+',
    '3+',
    '5+',
    '6+',
    '7+',
    'S+',
    'BR',
    'SF',
    'DC',
    'DN',
    'DO',
    '7N',
    '71',
    '74',
    'SN',
    'S1',
    'S4',
    'LT',
    'TA',
    'TF',
    'TN',
    'FN'
);


ALTER TYPE public.hd_product_code OWNER TO postgres;

--
-- Name: history_event; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.history_event AS ENUM (
    'CREATE',
    'MODIFY',
    'PROMOTE'
);


ALTER TYPE public.history_event OWNER TO postgres;

--
-- Name: region; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.region AS ENUM (
    'NA',
    'NE',
    'ND'
);


ALTER TYPE public.region OWNER TO postgres;

--
-- Name: status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'PENDING',
    'WITHDRAWN'
);


ALTER TYPE public.status OWNER TO postgres;

--
-- Name: sub_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.sub_type AS ENUM (
    'ATHLETIC',
    'PREMIUM',
    'BACK_COPY',
    'GIFT',
    'REFERRAL',
    'MESSAGE',
    'MAIL_SUBSCRIPTION',
    'IHT',
    'IHD',
    'BOOK_REVIEW',
    'LARGE_PRINT',
    'UPSELL',
    'BAU'
);


ALTER TYPE public.sub_type OWNER TO postgres;

--
-- Name: type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.type AS ENUM (
    'DIGITAL',
    'HD'
);


ALTER TYPE public.type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_iqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action_iqs (
    action_iq character varying NOT NULL
);


ALTER TABLE public.action_iqs OWNER TO postgres;

--
-- Name: bundles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bundles (
    code character varying NOT NULL
);


ALTER TABLE public.bundles OWNER TO postgres;

--
-- Name: offer_bundles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_bundles (
    offer_id uuid NOT NULL,
    bundle_code character varying NOT NULL
);


ALTER TABLE public.offer_bundles OWNER TO postgres;

--
-- Name: offer_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_categories (
    offer_id uuid NOT NULL,
    category public.category NOT NULL
);


ALTER TABLE public.offer_categories OWNER TO postgres;

--
-- Name: offer_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_channels (
    offer_id uuid NOT NULL,
    channel public.channel NOT NULL
);


ALTER TABLE public.offer_channels OWNER TO postgres;

--
-- Name: offer_hd_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_hd_products (
    offer_id uuid NOT NULL,
    hd_product_code public.hd_product_code NOT NULL,
    region public.region NOT NULL
);


ALTER TABLE public.offer_hd_products OWNER TO postgres;

--
-- Name: offer_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_history (
    id integer NOT NULL,
    offer_id uuid NOT NULL,
    user_id integer,
    modify_date timestamp without time zone DEFAULT now() NOT NULL,
    event public.history_event NOT NULL,
    note character varying,
    trace character varying
);


ALTER TABLE public.offer_history OWNER TO postgres;

--
-- Name: offer_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.offer_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offer_history_id_seq OWNER TO postgres;

--
-- Name: offer_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.offer_history_id_seq OWNED BY public.offer_history.id;


--
-- Name: offer_segments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_segments (
    offer_id uuid NOT NULL,
    action_iq_id character varying NOT NULL
);


ALTER TABLE public.offer_segments OWNER TO postgres;

--
-- Name: offer_sub_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_sub_types (
    offer_id uuid NOT NULL,
    sub_type public.sub_type NOT NULL
);


ALTER TABLE public.offer_sub_types OWNER TO postgres;

--
-- Name: short_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.short_id_seq
    START WITH 11000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.short_id_seq OWNER TO postgres;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    short_id character varying DEFAULT ('OM-'::text || nextval('public.short_id_seq'::regclass)) NOT NULL,
    type public.type NOT NULL,
    name character varying NOT NULL,
    status public.status NOT NULL,
    chain_id bigint,
    promo_id character varying,
    billing_frequency_in_weeks integer,
    expiring boolean NOT NULL,
    start_date timestamp without time zone DEFAULT now() NOT NULL,
    end_date timestamp without time zone,
    version character varying NOT NULL
);


ALTER TABLE public.offers OWNER TO postgres;

--
-- Name: offers_schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offers_schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.offers_schema_migrations OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: offer_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_history ALTER COLUMN id SET DEFAULT nextval('public.offer_history_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: action_iqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action_iqs (action_iq) FROM stdin;
\.
COPY public.action_iqs (action_iq) FROM '$$PATH$$/3715.dat';

--
-- Data for Name: bundles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bundles (code) FROM stdin;
\.
COPY public.bundles (code) FROM '$$PATH$$/3725.dat';

--
-- Data for Name: offer_bundles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_bundles (offer_id, bundle_code) FROM stdin;
\.
COPY public.offer_bundles (offer_id, bundle_code) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: offer_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_categories (offer_id, category) FROM stdin;
\.
COPY public.offer_categories (offer_id, category) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: offer_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_channels (offer_id, channel) FROM stdin;
\.
COPY public.offer_channels (offer_id, channel) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: offer_hd_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_hd_products (offer_id, hd_product_code, region) FROM stdin;
\.
COPY public.offer_hd_products (offer_id, hd_product_code, region) FROM '$$PATH$$/3721.dat';

--
-- Data for Name: offer_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_history (id, offer_id, user_id, modify_date, event, note, trace) FROM stdin;
\.
COPY public.offer_history (id, offer_id, user_id, modify_date, event, note, trace) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: offer_segments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_segments (offer_id, action_iq_id) FROM stdin;
\.
COPY public.offer_segments (offer_id, action_iq_id) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: offer_sub_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_sub_types (offer_id, sub_type) FROM stdin;
\.
COPY public.offer_sub_types (offer_id, sub_type) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offers (id, short_id, type, name, status, chain_id, promo_id, billing_frequency_in_weeks, expiring, start_date, end_date, version) FROM stdin;
\.
COPY public.offers (id, short_id, type, name, status, chain_id, promo_id, billing_frequency_in_weeks, expiring, start_date, end_date, version) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: offers_schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offers_schema_migrations (version, dirty) FROM stdin;
\.
COPY public.offers_schema_migrations (version, dirty) FROM '$$PATH$$/3713.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email) FROM stdin;
\.
COPY public.users (id, email) FROM '$$PATH$$/3718.dat';

--
-- Name: offer_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.offer_history_id_seq', 3278, true);


--
-- Name: short_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.short_id_seq', 11001, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: action_iqs action_iqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action_iqs
    ADD CONSTRAINT action_iqs_pkey PRIMARY KEY (action_iq);


--
-- Name: bundles bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bundles
    ADD CONSTRAINT bundles_pkey PRIMARY KEY (code);


--
-- Name: offer_history offer_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_history
    ADD CONSTRAINT offer_history_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: offers_schema_migrations offers_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers_schema_migrations
    ADD CONSTRAINT offers_schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: offer_bundles_offer_id_bundle_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_bundles_offer_id_bundle_code ON public.offer_bundles USING btree (offer_id, bundle_code);


--
-- Name: offer_categories_offer_id_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_categories_offer_id_category ON public.offer_categories USING btree (offer_id, category);


--
-- Name: offer_channels_offer_id_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_channels_offer_id_channel ON public.offer_channels USING btree (offer_id, channel);


--
-- Name: offer_hd_products_offer_id_hd_product_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_hd_products_offer_id_hd_product_code ON public.offer_hd_products USING btree (offer_id, hd_product_code, region);


--
-- Name: offer_segments_offer_id_aiqid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_segments_offer_id_aiqid_idx ON public.offer_segments USING btree (offer_id, action_iq_id);


--
-- Name: offer_sub_types_offer_id_subtype; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX offer_sub_types_offer_id_subtype ON public.offer_sub_types USING btree (offer_id, sub_type);


--
-- Name: offer_bundles offer_bundles_bundle_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_bundles
    ADD CONSTRAINT offer_bundles_bundle_code_fkey FOREIGN KEY (bundle_code) REFERENCES public.bundles(code);


--
-- Name: offer_bundles offer_bundles_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_bundles
    ADD CONSTRAINT offer_bundles_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_categories offer_categories_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_categories
    ADD CONSTRAINT offer_categories_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_channels offer_channels_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_channels
    ADD CONSTRAINT offer_channels_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_hd_products offer_hd_products_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_hd_products
    ADD CONSTRAINT offer_hd_products_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_history offer_history_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_history
    ADD CONSTRAINT offer_history_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_history offer_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_history
    ADD CONSTRAINT offer_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: offer_segments offer_segments_action_iq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_segments
    ADD CONSTRAINT offer_segments_action_iq_id_fkey FOREIGN KEY (action_iq_id) REFERENCES public.action_iqs(action_iq);


--
-- Name: offer_segments offer_segments_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_segments
    ADD CONSTRAINT offer_segments_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offer_sub_types offer_sub_types_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_sub_types
    ADD CONSTRAINT offer_sub_types_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DATABASE test; Type: ACL; Schema: -; Owner: alexwilkerson
--

GRANT ALL ON DATABASE test TO postgres;


--
-- PostgreSQL database dump complete
--

